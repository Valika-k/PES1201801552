﻿<!DOCTYPE HTML>

<html>
<head>
		<title>Inspiration</title>
	<!--	<meta http-equiv="content-type" content="text/html; charset=utf-8" />
		<meta name="description" content="" />
		<meta name="keywords" content="" />-->
		<link href='http://fonts.googleapis.com/css?family=Arimo:400,700' rel='stylesheet' type='text/css'>
		<!--[if lte IE 8]><script src="js/html5shiv.js"></script><![endif]-->
	<!--	<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.11.0/jquery.min.js"></script>-->
		<script src="js/skel.min.js"></script>
		<script src="js/skel-panels.min.js"></script>
		<script src="js/init.js"></script>
		<noscript>
			<link rel="stylesheet" href="css/skel-noscript.css" />
			<link rel="stylesheet" href="css/style.css" />
			<link rel="stylesheet" href="css/style-desktop.css" />
		</noscript>
		<!--[if lte IE 8]><link rel="stylesheet" href="css/ie/v8.css" /><![endif]-->
		<!--[if lte IE 9]><link rel="stylesheet" href="css/ie/v9.css" /><![endif]-->
		<style>


	#header
	{
	/*	position: relative;
		background: #2a2f27 url(a10.png) no-repeat;
	background-size: 1500px 650px;*/
		background:#333 url(a10.png) ;
		width:100%;
		background-repeat:no-repeat;
		height: 50%;
		background-size:1550px 650px;
		font-family:Arial;
	}
	mark{
		background-color: black;
		color:white;
	}
	/*.blur{
		position:relative;
		left:10%;
	  top:50%;
	  background-color: rgba(255, 255, 255, 0.3);
	  border-radius: 5px;
	  font-family: sans-serif;
	  text-align: center;
	  line-height: 1;
	 -webkit-backdrop-filter: blur(5px);
	  backdrop-filter: blur(20px);
	  max-width: 70%;
	  max-height: 30%;
	  padding: 0px 80px;
	}*/
	.container {
		width: 1200px;
		left:50%
	/*	margin-left: auto;
		margin-right: auto;*/
	}

	/* Modifiers */

		.container.small {
			width: 2000px;
		}

		.container.big {
			width: 200%;
			max-width: 1500px;
			min-width: 1200px;
		}
		.image
		{
			display: inline-block;
		}

			.image img
			{
				display: block;
				width: 100%;
			}

			.image.featured
			{
				display: block;
				width: 100%;
				margin: 0 0 2em 0;
			}

			.image.full
			{

				display: block;
				width: 150%;
				margin: 0 0 2em 0;
			}
			.image.full1
			{
				display: block;
				width: 100%;
				margin: 0 0 2em 0;
			}

			.image.left
			{
				display: block;
				width: 40%;
				float: left;
				margin: 0 2em 2em 0;
			}
			.image.right
			{
				display: block;
				width: 40%;
				float: right;
				margin: 0 2em 2em 0;
			}
			.image.centered
			{
				display: block;
				margin: 0 0 2em 0;
			}

				.image.centered img
				{
					margin: 0 auto;
					width: auto;
				}
	</style>
	</head>
	<body class="homepage">

		<!-- Header -->
		<div id="header">
			<div class="container">

				<!-- Logo -->
				<div id="logo">
					<div class="blur">
					<h1 ><a href="#">She Matters!</a></h1>
					<span><mark>Someone has to lead.</mark></span>
				</div>
				</div>

				<!-- Nav -->
				<nav id="nav">
					<ul>
						<li><a href="index2.php">Home</a></li>
						<li><a href="welcome.php">Our Blog</a></li>
							<li class="active"><a href="#">Inspiration</a></li>
						<li><a href="https://www.instagram.com/_she_matters_/?hl=en">Media</a></li>
						<li><a href="black_and_white/contact.html">Contact</a></li>



					</ul>
				</nav>
			</div>
		</div>

		<!-- Main -->
		<div id="main">
			<div class="container">
				<div class="row">

					<!-- Content -->
					<div id="content" class="12u skel-cell-important">
						<section>
							<header>
								<h2>Inspiration</h2>
								<span class="byline">If you get, give. If you learn, teach</span>
							</header>
		<div id="featured">
			<p style="margin:30px; font-weight:bold;"> Read these stories to get inspired by these wonderful women who have overcome their hurdles and faced every tough situation, that the society or their own family has put upon them. Their stories are so painful and touching but the way that they have dealed with it is so brave and inspiring. Their efforts to brighten their future and the way they took the stand must be read and followed. So here you go, meet these wonderful people and learn how to get strong and independent.</p>
			<br>
			<div class="container">
			<!--	<div class="row">-->
				<!--	<div class="4u">-->

						<a href="#" style="margin:30px;" class="image left"><img src="images1/a2.jpg" alt="" /></a>
						<p style="margin:30px;">"I was 10,when one day I woke up to see a bunch of my hair fallen on my pillow. When I combed it, more fell off. Days passed & I started observing bald patches on my head. My parents & I consulted many doctors but nobody could diagnose my condition. Finally we found a doctor who told us what was wrong- I had Alopecia. But we had no idea about the cure. Every day I saw my hiar falling along with my confidence. It was hard to accept the reality. Things got worse when I had to go to school.Students made fun of me-even teachers gave me weird stares. I'd be by myself most of the time & some days I'd lock myself in the bathroom & cry. I remember once, I was invited to a friend's party & wanted to wear this pretty dress.But I was scared of going,I thought people would humiliate me. That's when my mom said, 'It doesn't matter what people think, they'll ridicule you anyway- so do what makes you happy!' It was a simple sentence but yet so empowering. With hesitance & a little hope-I wore the dress & went to the party. I realised that it didn't matter what people thought of me-I accepted myself & it made life better. A few years later, when I was in college, a doctor in Kolkata. That was taking so much energy out of me. I was putting do much pressure to be a certain way- when I was actuallyat peace, with how I looked It was that time when I threw my medications into the trash - slong with the hair that i shaved off my head. I trualy embraced my identity. I'm 30 and even today people ask me me if I have cancer or if I've shaved off my head because of religious beliefs.I still stnd out amongst the crowd, but it doesn't bother me anymore. I'm living life the way I want. I'm working in the field of marketing and waking up to a confident self.When I look in the mirror, I don't see flaws. I wear a pair of earrings to match my confidence.Because for me, life isn't about what I lack-it's about owning my beauty, irrespective of whether it matches anyone's standard or not "
						</p>
						<hr>
					<!--	<p><a href="#" class="button">More Details</a></p>-->
					</div>
					<div class="container">
				<!--	<div class="4u">-->

						<a href="#" style="margin:30px;" class="image right"><img src="images1/a4.jpg" alt="" /></a>
						<p style="margin:30px;">“I wasn’t like this 2 years back – I was just another housewife. I hated it but I had little to no choice. My marriage wasn’t working out – my husband and I were unhappy with each other. Often we do things just because we feel like ‘we have to do’ or because it’s our ‘duty’ and just forget about our happiness. I was there too. I started having dark thoughts and didn’t have any distractions; nothing to divert my mind from that negative energy.  I became a quiet person. Until one day, I found the courage to say the simple words — ‘I want a divorce’. I was firm. I even moved back home. After that, it felt like I could finally live the way I wanted to. I even joined my family business at this store. I could feel myself gaining an identity again — and discovering my capabilities. Something I hadn’t done for years. I’m trying to put memories of all those difficult years behind me. Now I wake up every morning looking forward to my day. I love meeting new people and working hard for a living — for myself. And whenever I’m feeling anxious about the future, I just come here, breathe in the fresh air and remind myself that I’m not trapped anymore – I’m free to just be me...and that means that I have nothing to be afraid of.”
						</p>
						<br>
						<hr>
					<!--		<p><a href="#" class="button">More Details</a></p>-->
					</div>
					<div class="container">
				<!--	<div class="4u">-->

						<a href="#" style="margin:30px;" class="image left"><img src="images1/a5.jpg" alt="" /></a>
						<p style="margin:30px;">        “I was detected with Polio when I was one & a half years old. My parents thought I was a burden, so before I turned 2, they got me married.
        When I got to know about this, I couldn’t believe that my parents would do something like this just to get rid of me.
        When I was 12, my husband started forcing me to work on his farm. I couldn’t even walk properly, but he treated me like a slave. Then, he got married to another girl without my knowledge.
        I wanted to leave, but my parents refused to take me back, so I was forced to live with my husband & his other wife.
        A few years later, my husband met with an accident & passed away—& that made my life worse. My in-laws didn’t allow me to go out & barely gave me food. They even accused me of aborting a child I had through an ‘extramarital affair’.
        I couldn’t take it anymore. From the time I was born my reality was a nightmare & it kept getting worse. It was time for me to speak up.
        When I finally did, I was thrown out of the house. Then my in-laws filed a case against me—to take my share from the family property.
        My life had become hell & I could sense my end coming. But I had promised myself that I wouldn’t end my life. I lived with hope; that life would get better.
        During this time, someone told me to take this matter up to the women’s grievance cell in Ajmer. I was hesitant at first, but I realized—it’s now or never. So I approached them & there, for the first time...I was heard. They supported me, helped me fight the legal battle & when I won, I couldn’t hold back my tears.
        That’s when I decided that I won’t let anyone suppress me & would dedicate my life to uplifting women who had gone through trauma.
        It’s been 20 years since & I’ve helped over 2000 women. But, the fight is still on. My past still haunts me, but it also reminds me that it's only when you speak up & fight, will things change. I no longer hide myself behind a ‘purdah’ & have stopped living according to societal norms. I’ve even started wearing coloured clothes again! I’ve re-built myself from the ashes & broken free from the shackles that caged me. And if I can help every woman who is fighting a similar battle, do the same, it would be a life well lived!"


</p>
<hr>
					<!--	<p><a href="#" class="button">More Details</a></p>-->
					</div>
					<div class="container">
					<!--	<div class="4u">-->

						<a href="#" style="margin:30px;" class="image right"><img src="images1/a6.jpg" alt="" /></a>
						<p style="margin:30px;">    “My father passed away when I was really young, so I started working to support the family. I tried my hand at everything. I learnt how to cook, and joined an agency where they’d send me all over India to cook for weddings. I learnt how to apply mehendi and even set up this small shop here -- where I sit in my free time. I contributed at home, and helped my mother and brothers keep the house going.
    Whenever I’d get any suitors, I’d reject them because I always felt that I had so much more left to do, so much more left to help. And that if I get married, I wouldn’t be able to do any of it.
    A few years back, one of our neighbours -- who was a very old lady. She fell very sick, and didn’t have anybody to take care of her. So I’d spend the whole day with her, and even shifted my shop right outside her doorstep. But her condition went from bad to worse, and eventually she passed away. It broke my heart.
    That made me realise how inevitable things are, that no matter what you do or what you think you can do to change it -- life is what it is. I realised that I’d spent a lot of my life for others. Thinking that it was my duty, but I also had a responsibility towards myself. It took a while but now I’ve slowed down, I still work but I’m focusing more on myself. I recently discovered that I love travelling, so I’m going to save up and travel abroad. I don’t know where, I'm not so good with names. But somewhere nice. Also, I realised that I don’t want to travel alone… so the first thing I’m doing now is try to find the love of my life. Let me know if you have anyone in mind for me!”



						</p>
					<!--	<p><a href="#" class="button">More Details</a></p>-->
					<hr>
					</div>
					<div class="container">
				<!--	<div class="4u">-->

					<a href="#" style="margin:30px;"class="image left"><img src="images1/a1.jpg" alt="" /></a>
					<p style="margin:30px;">
“As a child, I had to grow up too quickly & become responsible too soon. I had 6 siblings and took care of them all after we lost our mother at a very young age. After both my sister’s were married off, my dad, brother & I moved to the city. I began working since then, because money was tight. Somewhere along the way, we discovered that my brother had a hole in his heart… he passed away soon after that. My dad couldn’t handle the shock of losing him & stopped working. I took up a job as a typist to sustain, but when I was 26, I even lost my dad.
I didn’t have anything to live for. I’d spent my life working for my family & then… there was no one left. I continued working as a typist & living alone.
This one day, I saw a young boy Rajat—he was specially abled & used to work at a dhaba near my office. I used to see him getting beat up everyday. I tried to find his parents, but he had no one. So one day, when he was getting beaten, I intervened & took him home. I knew what it was like to have no one & no help. I started taking care of Rajat & even educated him. As I saw how his life changed, I realised that there were so many other children like him who had no one.
I visited childcare homes to see how they work & how they take care of these kinds. I began saving every penny I made to help more kids & within a year, I started my own orphanage Bal Kutir from home.
We started getting kids from the police, from the streets & through word of mouth—they were either lost, abandoned or orphaned at birth.
I once got a baby who was just 4 days old. It was heartbreaking, but I was happy to give him a second chance. Once we started getting donors, I quit my job & focused on the home full-time.
It’s been two decades now—& we’ve helped more than 120 kids! Rajat is grown up now & has a great job in management!
It’s because of this kind of impact that I look forward to waking up everyday... because I know I’m making a difference, where it’s needed the most. Life wasn’t as fair to me and my family. Maybe if things were in our favour, we would’ve all been together today. But I’ve come to terms with it & now I’ve found my family in all of these kids—& they’ve found one in me too.”
</p><!--<p><a href="#" class="button">More Details</a></p>-->
<hr>
				</div>



			<div class="container">
		<!--	<div class="4u">-->

			<a href="#" style="margin:30px;" class="image right"><img src="images1/a3.jpg" alt="" /></a>
			<p style="margin:30px;">


“I was in my second year of college when my dad introduced me to Raj. I fell for him instantly & knew that he’s the guy for me. We dated for 6 months before I graduated & got married to him.
Life was perfect. I decided to be a homemaker–I wanted to take care of him with all my heart. Everything was smooth–he was the love of my life! I gave birth to my daughter 2 years later & our family was complete.
But a few months back, suddenly one night, we lost him to a brain hemorrhage. There were no signs. He never smoked or drank. He was gone before I could process what was happening. It shook my world to its core.
What felt like a complete family one morning, became an irreplaceable void the next. I couldn’t move on. My daughter was barely 3 years old. She’d ask me where her dad was & I’d tell her that he was in the sky. We’d wave to the sky & talk to him. She was young & despite that she understood that I was hurting, that things have changed--she’d never let me be sad. She’d always do something to make me smile.
After a few days, I came to the realisation that unless I help myself up--neither me nor my daughter would be able to move forward. I decided to wipe my tears & rebuild my life.
I moved in with my parents. I worked day & night to appear for the LIC exam—I wanted to become an insurance agent. I was constantly looking for avenues to earn. I’d paint when I was younger, so I took that up again & started selling my paintings.
When I sold my first painting, I took my daughter to her favourite restaurant. She was excited to have Pav Bhaji–the smile on her face gave me the strength I needed, to believe that I could do this for her, alone.
When I passed the exam & became an insurance agent, things started looking up from there.
I still miss Raj everyday, I wish he was with us so we could do all the things that families do. But I’ve learnt to keep him in my memories, & deal with reality. Our past has scarred both me & my daughter, but I’m going to put her happiness first. I’m going to hold her hand & guide her through life, every step of the way. And I hope Raj is smiling down at us, knowing that his love is being carried forward in his memory.”

			</p>
		<!--	<p><a href="#" class="button">More Details</a></p>-->
		<hr>
		</div>


					<div class="container">
				<!--	<div class="4u">-->

					<a href="#" style="margin:30px;" class="image left"><img src="images1/a7.jpg" alt="" /></a>
					<p style="margin:30px;">


						“My mom passed away in an accident when I was 9. Before I could deal with the shock of it, my dad was arrested for being the prime suspect for her death. My world was destroyed overnight.
					My aunt & uncle became my custodians & for 5 years I lived with them. It was terrible. Everyone had their parents attending school functions but nobody would be there for me. I was all alone & barely had a childhood.
					When I turned 15, my dad was released from jail. I was just grateful that I could live with him again. So when he decided to remarry, I agreed.
					But after marriage, my stepmom didn’t accept me & my dad asked me to move out. I didn’t want to go back to my aunt, so even though it was heartbreaking–I stood my ground. My dad even stopped giving me food, money & clothes–but I gave tuitions to sustain.
					Soon my step mom got pregnant, so she came up to me & said, ‘I don't want even your shadow to fall on my child’–my dad & her left the house.
					I was broken & had no strength to continue. But, that’s when one of my students’ mom, who knew what was happening in my life, asked me to move in with her. She wanted someone to take care of her kids full time. It was the only ray of hope I had.
					So I moved in with her & she treated me like her own. She gave me everything I needed. We’d go out like a family, eat together like a family – something I’d never done. She even paid my college fees. I understood what having a family felt like, because of a stranger.
					Soon after college, I got a job & finally found stability. Living with this lady helped me move on from my past & understand that there is hope for everybody.
					Recently I got married & my ‘adoptive mom’ even did my Kanya Daan. I realised what happiness was, when I saw her performing all the rituals a parent would, at my wedding!
					Sometimes we undervalue the simple things in life, we don’t understand how important it is to cherish them–for me, that thing was, family. I’ve spent half my life wanting a parent’s love & not getting it. But I have it now, a mother not by blood–but just by pure love. And it’s something I’m going to be grateful for, forever. Because I know now, not to take for granted the things that life gives us easily."
					</p>
				<!--	<p><a href="#" class="button">More Details</a></p>-->

				</div>





		<!-- Footer -->
		<div id="footer">
			<div class="container">
				<!--<div class="row">
					<div class="4u">
						<section>
								<a href="#" class="image full1"><img src="images/w6.png" alt="" /></a>
						<!--<h2>Latest Posts</h2>
							<ul class="default">
								<li><a href="#">Pellentesque lectus gravida blandit</a></li>
								<li><a href="#">Lorem ipsum consectetuer adipiscing</a></li>
								<li><a href="#">Phasellus nibh pellentesque congue</a></li>
								<li><a href="#">Cras vitae metus aliquam pharetra</a></li>
								<li><a href="#">Maecenas vitae orci feugiat eleifend</a></li>
							</ul>
						</section>
					</div>

					<div class="4u">
						<section>
							<a href="#" class="image full1"><img src="images/w3.png" alt="" /></a>
						<!--	<h2>Ultrices fringilla</h2>
							<ul class="default">
								<li><a href="#">Pellentesque lectus gravida blandit</a></li>
								<li><a href="#">Lorem ipsum consectetuer adipiscing</a></li>
								<li><a href="#">Phasellus nibh pellentesque congue</a></li>
								<li><a href="#">Cras vitae metus aliquam pharetra</a></li>
								<li><a href="#">Maecenas vitae orci feugiat eleifend</a></li>
							</ul>
						</section>
					</div>
					<div class="4u">
						<section>-->
							<a href="#" class="image full1"><img src="images1/w1.png" alt="" /></a>
					</div>
		</div>




		</body>
		</html>
