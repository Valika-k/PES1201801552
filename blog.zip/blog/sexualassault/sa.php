<html>
<head>
<meta charset ="UTF-8">
<style>

ul {
  list-style-type: none;
  margin: 0;
  padding: 0;
  overflow: hidden;
  background-color: grey;
}

li {
  float: left;
}

li a {
  display: block;
  color: black;
  text-align: center;
  padding: 14px 16px;
}

li a:hover {
  background-color: white;
}

#header {
  background-color: white;
  padding: 30px 10px;
  color: black;
  text-align: center;
  font-size: 70px;
  font-weight: bold;
  position: fixed;
  top: 0;
  width: 100%;
  transition: 0.2s;
}

body {
  background-color: black;
}

body {font-family: Arial, Helvetica, sans-serif;}

.image-container {
  background-image: url("sa5.JPG");
  background-size: cover;
  position: relative;
  height:700px;
}

.text {
  background-color: white;
  color: black;
  font-size: 9vw;
  font-weight: bold;
  margin: 0 auto;
  padding: 10px;
  width: 50%;
  text-align: center;
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  mix-blend-mode: screen;
}

body {
  color: white;
}

.center {
  text-align: center;
  text-size-adjust: 80%;
}

pre.b {
  font-family: "Times New Roman";
  font-size: 65%;
  padding-left: 35px;
  padding-right: 25px;
  padding-top: 600px;
  padding-bottom: 50px;
}

pre.a {
  font-size: 70%;
}

pre.c {
  font-family: "Times New Roman";
  font-size: 65%;
  padding-left: 15px;
  padding-top: 700px;
  padding-bottom: 50px;
}

div.gallery {
  margin: 5px;
  border: 1px solid #ccc;
  float: left;
  width: 400px;
}

div.gallery:hover {
  border: 1px solid #777;
}

div.gallery img {
  width: 100%;
  height: auto;
}

div.desc {
  padding: 15px;
  text-align: center;
}
</style>
</head>


<body>

<div id="header">SEXUAL ASSAULT</div>
<div style="margin-top:200px;padding:15px 15px 2500px;font-size:30px">

<!--  <ul>
    <li><a href="index2.php">Home</a></li>
    <li><a class="active" href="welcome.php">Our Blog</a></li>
    <li><a href="inspiration.php">Inspiration</a></li>
    <li><a href="contact.html">Contact</a></li>
  </ul>
-->
<div class="image-container">
  <div class="text">STAY STRONG</div>

</div>
<div class="center">
    <pre class="a">



Sexual assault covers a wide range of unwanted sexual behaviours that are often used by offenders as
 a way to assert power and control over their victims. There are many myths around what constitutes
 sexual assault, so find out the facts. If you have been sexually assaulted, you might experience a range
 of emotions and it’s important to know there are support services that can help you.


    </pre>
</div>

<div class="gallery">
  <a target="_blank" href="sa7.JPG">
    <img src="sa7.JPG" alt="Domestic Violence" width="600" height="400">
  </a>
</div>

<div class="gallery">
  <a target="_blank" href="sa4.JPG">
    <img src="sa4.JPG" alt="Domestic Violence" width="600" height="400">
  </a>
</div>
<div class="gallery">
  <a target="_blank" href="sa3.JPG">
    <img src="sa3.JPG" alt="Domestic Violence" width="600" height="400">
  </a>
</div>

<div class="gallery">
  <a target="_blank" href="sa8.JPG">
    <img src="sa8.JPG" alt="Domestic Violence" width="600" height="400">
  </a>
</div>

<div class="gallery">
  <a target="_blank" href="sa2.JPG">
    <img src="sa2.JPG" alt="Domestic Violence" width="600" height="400">
  </a>
</div>

<div class="gallery">
  <a target="_blank" href="sa6.JPG">
    <img src="sa6.JPG" alt="Domestic Violence" width="600" height="400">
  </a>
</div>

<pre class="b">

What is rape?
Rape is a form of sexual assault, but not all sexual assault is rape. The term rape is often used as a legal definition to specifically include sexual penetration
without consent.For its Uniform Crime Reports, the FBI defines rape as “penetration, no matter how slight, of the vagina or anus with any body part or object, or
oral penetration by a sex organ of another person, without the consent of the victim.”

What is force?
Force doesn’t always refer to physical pressure. Perpetrators may use emotional coercion, psychological force, or manipulation to coerce a victim into
non-consensual sex. Some perpetrators will use threats to force a victim to comply, such as threatening to hurt the victim or their family or other intimidation
tactics.

Who are the perpetrators?
The majority of perpetrators are someone known to the victim. Approximately eight out of 10 sexual assaults are committed by someone known to the victim, such as
in the case of intimate partner sexual violence or acquaintance rape.

The term “date rape” is sometimes used to refer to acquaintance rape. Perpetrators of acquaintance rape might be a date, but they could also be a classmate, a
neighbor, a friend s significant other, or any number of different roles. It’s important to remember that dating, instances of past intimacy, or other acts
like kissing do not give someone consent for increased or continued sexual contact.

In other instances the victim may not know the perpetrator at all. This type of sexual violence is sometimes referred to as stranger rape. Stranger rape can
occur in several different ways:
Blitz sexual assault: when a perpetrator quickly and brutally assaults the victim with no prior contact, usually at night in a public place
Contact sexual assault: when a perpetrator contacts the victim and tries to gain their trust by flirting, luring the victim to their car, or otherwise trying to coerce
the victim into a situation where the sexual assault will occur
Home invasion sexual assault: when a stranger breaks into the victim's home to commit the assault
Survivors of both stranger rape and acquaintance rape often blame themselves for behaving in a way that encouraged the perpetrator. It’s important to remember that the
victim is a never to blame for the actions of a perpetrator.


</pre>
<div class="gallery">
  <a target="_blank" href="sa11.JPG">
    <img src="sa11.JPG" alt="Domestic Violence" width="600" height="400">
  </a>
</div>

<div class="gallery">
  <a target="_blank" href="sa13.JPG">
    <img src="sa13.JPG" alt="Northern Lights" width="600" height="400">
  </a>
</div>

<div class="gallery">
  <a target="_blank" href="sa12.JPG">
    <img src="sa12.JPG" alt="Domestic Violence" width="600" height="400">
  </a>
</div>

<pre class="c">
  Proving Sexual Assault Charges

  In general, sexual assault is involuntary sexual contact that occurs through the actor's use of force, coercion or the victim's incapacitation. The law will consider
  the victim incapacitated if he or she did not have the mental ability to understand the nature of the sexual acts, or if the victim was physically incapable of
  indicating their unwillingness to participate in the sexual conduct. Common examples of these charges may arise from the use of alcohol or date rape drugs, both of
  which can make it impossible for a victim to legally consent to sexual conduct.

  Modern laws covering this subject area include the nonconsensual sexual contact that occurs between any sex and between people of any age. For example, most laws
  cover involuntary sexual contact occurring between two men, two women or two children, etc., not just an adult man and woman.

  Most states have made sexual assault the umbrella term for other crimes, such as rape and unwanted sexual contact. Some states distinguish between crimes involving
  penetration and crimes involving coerced or involuntary touching, making the former an aggravated or first-degree sexual assault and the latter a lower-level sexual assault.

</pre>
<div class="gallery">
  <a target="_blank" href="sa9.JPG">
    <img src="sa9.JPG" alt="Domestic Violence" width="600" height="400">
  </a>
</div>

<div class="gallery">
  <a target="_blank" href="sa10.JPG">
    <img src="sa10.JPG" alt="Domestic Violence" width="600" height="400">
  </a>
</div>

<div class="gallery">
  <a target="_blank" href="sa1.JPG">
    <img src="sa1.JPG" alt="Domestic Violence" width="600" height="400">
  </a>
</div>

<div class="gallery">
  <a target="_blank" href="S1.JPG">
    <img src="S1.JPG" alt="Domestic Violence" width="600" height="400">
  </a>
</div>

<div class="gallery">
  <a target="_blank" href="S3.JPG">
    <img src="S3.JPG" alt="Domestic Violence" width="600" height="400">
  </a>
</div>

<div class="gallery">
  <a target="_blank" href="S2.JPG">
    <img src="S2.JPG" alt="Domestic Violence" width="600" height="400">
  </a>
</div>




<script>
window.onscroll = function() {scrollFunction()};

function scrollFunction() {
  if (document.body.scrollTop > 50 || document.documentElement.scrollTop > 50) {
    document.getElementById("header").style.fontSize = "30px";
  } else {
    document.getElementById("header").style.fontSize = "90px";
  }
}
</script>


</body>
</html>
