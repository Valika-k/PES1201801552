﻿<!DOCTYPE HTML>
<html>

<head>
  <title>black &amp; white - a page</title>
  <meta name="description" content="website description" />
  <meta name="keywords" content="website keywords, website keywords" />
  <meta http-equiv="content-type" content="text/html; charset=windows-1252" />
  <link rel="stylesheet" type="text/css" href="style/style.css" title="style" />
  <noscript>
    <link rel="stylesheet" href="css/skel-noscript.css" />
    <link rel="stylesheet" href="css/style.css" />
    <link rel="stylesheet" href="css/style-desktop.css" />
  </noscript>
  <style>
  body
  {
    background: #141414;
  }

  body,input,textarea,select
  {
    font-family: 'Arimo', sans-serif;
    font-size: 11pt;
    line-height: 1.75em;
    color: #4c4c4c;
  }
  .container {
    padding: 20px 40px;
    width: 800px;
    left:80%
  /*	margin-left: auto;
    margin-right: auto;*/
  }

  .container.small {
    width: 2000px;
  }

  .container.big {
    width: 200%;
    max-width: 1500px;
    min-width: 1200px;
  }
  .image
  {
    display: inline-block;
  }

    .image img
    {
      display: block;
      width: 100%;
    }

    .image.featured
    {
      display: block;
      width: 100%;
      margin: 0 0 2em 0;
    }

    .image.full
    {

      display: block;
      width: 150%;
      margin: 0 0 2em 0;
    }
    .image.full1
    {
      display: block;
      width: 40%;
      margin: 0 0 2em 0;
    }

    .image.left
    {
      display: block;
      width: 40%;
      float: left;
      margin: 0 2em 2em 0;
    }
    .image.right
    {
      display: block;
      width: 40%;
      float: right;
      margin: 0 2em 2em 0;
    }
    .image.centered
    {
      display: block;
      margin: 0 0 2em 0;
    }

      .image.centered img
      {
        margin: 0 auto;
        width: auto;
      }

  /*.box {
  font-size:20px;
  left:50%;
  top:50%;

  background-color: rgba(255, 255, 255, 0.3);
  border-radius: 5px;
  font-family: sans-serif;
  text-align: center;
  line-height: 1;
 -webkit-backdrop-filter: blur(20px);
  backdrop-filter: blur(20px);
  max-width: 200%;
  max-height: 200%;
  height: 100%;
  width: 80%;
   line-height: 1.7em;
  padding: 20px 40px;
}*/
.button {
  background-color: #4CAF50; /* Green */
  border: none;
  color: white;
  padding: 16px 32px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 16px;
  margin: 4px 2px;
  -webkit-transition-duration: 0.4s; /* Safari */
  transition-duration: 0.4s;
  cursor: pointer;
}

.button1 {
  background-color: white;
  color: black;
  border: 2px solid black;
  border-radius: 4px;
  padding: 8px 20px;
}

.button1:hover {
  background-color: black;
  color: white;
  border-radius:4px;
  padding: 8px 20px;
}
#more {display: none;}
</style>
</head>

<body>
  <script>
 function myFunction() {
var dots = document.getElementById("dots");
var moreText = document.getElementById("more");
var btnText = document.getElementById("myBtn");

if (dots.style.display === "none") {
  dots.style.display = "inline";
  btnText.innerHTML = "Read more";
  moreText.style.display = "none";
} else {
  dots.style.display = "none";
  btnText.innerHTML = "Read less";
  moreText.style.display = "inline";
}
}



</script>
  <div id="main">
    <div id="header">
      <div id="logo">
        <div id="logo_text">
          <!-- class="logo_colour", allows you to change the colour of the text -->
          <h1><a href="index.html">Untold<span class="logo_colour"> Stories</span></a></h1>
          <h2>Unlifted Silence</h2>
        </div>
      </div>

    </div>
    <div id="content_header"></div>
    <div id="site_content">

        <h1 >Untold Myseries</h1>
       <p class="container" style="font-weight:bold;">The culture and tradition of India is considered as old and great all over the world where people used to worship various female goddesses,saints and poets. India is also a powerful nation and famous worldwide for being the largest democracy in the world however, women backwardness is also very clear in the Indian society because of the social issues, problems and lots of restrictions against women. Women belong to the lower and middle class family suffers more than the women of higher class family. Women in the Indian society generally face problems of sex discrimination, high percentage of illiteracy, female infanticide, dowry system, etc.
        Here are few stories where women have faced different problems.These are sad to narrate and and shouldn't be faced by any another women. These are the real stories that any woman could ever suffer.</span></p>

        <p class="container">


          <a href="#" class="image right"><img src="d7.png" alt="sorry" /></a>India may have banned two-finger virginity test, but three years on doctors are still subjecting rape victims to the humiliating and invasive procedure instead of using the government’s rape tests kits, re-traumatising already vulnerable women.

  Yashvi*, 23, says she has been trying for over eight months to get justice after she was raped by her colleague in Bhopal, India.

  Despite identifying her attacker, he has still not been arrested, as police have been relying solely on witness testimonies and, crucially, the discredited two-finger test.

  “If rape kits were available my case wouldn’t have taken this long. I am trying hard [to get justice] because I don’t want other women to go through this”, she says.

  The test, described by Human Rights Watch as “invasive, humiliating, and inhumane”, involves inserting two fingers into the vagina for doctors to then assess its laxity before making a conclusion on whether the woman has had sex. The inefficient test was banned by India in 2016, but appears to still be used.


  In June 2018, Maneka Gandhi, India’s Women and Child Development Minister, announced that SAFE kits (Sexual Assault Forensic Evidence) would be distributed to all hospitals across India. In cases of rape allegations, kits can carry out immediate medical investigation and collect forensic evidence. Each kit has a set of swabs, test tubes, chemicals for preservation and bottles to secure hair, urine, saliva samples, without which rape cases fall apart.

  “Where I am from it is not unusual for men to think they can get away with rape because they know that the two-finger test records no evidence”, says Ishani*, who was raped by her uncle for five months until she was able to escape and report the incident. She went to get herself tested at Dewas Government Hospital in Madhya Pradesh in June 2019 – but doctors still used the two-finger test.

  One of the problems is that the government is currently only supplying kits to a selected number of hospitals, with many not having access. Supply depends on national and state level budgets, said Dr Ulhas Gonnade, head of forensic medicine at Government Medical College Raipur, and so only hospitals with highly sophisticated labs are given priority.

  In Madhya Pradesh, the state with highest number of rape cases according to National Crime Records Bureau (NCRB), the kits are not available.

  “Everyone is only aware of the two-finger test here, they don’t know it is a malpractice” said Amu Vinzuda, programme coordinator for Jansahas, a charity which supports women who are victims of violence.

<span id="dots">...</span><span id="more">

  But Ravi Kant, an advocate at the Supreme Court of India who has worked with survivors for more than 20 years fighting assault cases, said police in rural areas often don’t have the kits ready.

  “It requires investment and specialised training, police have no idea how these kits work and sometimes simply ask victims to procure them,” he said.

  “This is not how rape should be responded to, our law enforcement has never been trained for assault against women,” added Kant.

  “The crime is against the state, they need to support victims.”

  There is also a lack of protocol in dealing with rape cases in police departments, with only Goa and Delhi police having a set of standard guidelines. Little to no trust in police and low conviction rates are seen as the main factors that prevent women from reporting assaults.

  According to one national survey, 99 per cent of cases involving sexual assault go unreported in India. For Ishani, police were reluctant to lodge a complaint because her assaulter was an influential government employee – they even suggested that Yashvi  marry her rapist.

  “Their aim is to get as few rape cases on record as possible, and so their first attempt is to scare victims,” said Manju Chouhan, a social worker at JanSahas.

  Inspector Sunil Yadav, from Dewas district police station in Madhya Pradesh, denied all claims regarding police being uncooperative.

  “This is untrue, it doesn’t happen in my station”, he said.

  Hospital staff are also often unsupportive, and it is becomes an extremely harrowing experience for victims, explained Ms Chouhan.

  Yashvi recounted how her nurse rebuked her during her examination: “Because of your sexual pleasures, our time is constantly wasted.”

  She said she was traumatised by the medical staff at Jabalpur Government Hospital, with the doctor telling her how he was “fed up” of going to the court constantly to give testimonies.
</span>
<button  class="button1" onclick="myFunction()" id="myBtn">Read more</button>
</p>


<br><hr>
  <p class="container">


  <a href="#" class="image left"><img src="d8.png" alt="sorry" /></a>Like Niyem, who, at 10 years old was kidnapped and loaded into a truck full of other women destined for a military camp in West Java. She shared a small tent with two other girls, where soldiers openly raped them. "I was still so young," she is quoted by Janssen as saying. "Within two months my body was completely destroyed. I was nothing but a toy, as a human being I meant nothing, that's how it felt during the Japanese era."

When Niyem managed to escape and return home two months later, her parents didn't recognize her: "I didn't dare tell anyone that I had been raped, I didn't want to hurt my parents. I was afraid that no one would want me, that I would be left out. But people still abused me by calling me a 'Japanese hand-me-down.' Because I had been gone so long, they suspected what had happened. It hurt me tremendously."

Perhaps it's inappropriate to say that Niyem was "lucky" to make it out alive. Many women died during the war; but many more survivors would live with a suppressed emotional trauma for the rest of their lives — too embarrassed to tell even their most loved ones.


</p>
<hr>
<p class="container">
      <a href="#" class="image right"><img src="d5.png" alt="sorry" /></a>
  Violence against women is deeply entrenched in the feudal, patriarchal Indian society, where for the rapist, every woman is fair game.

In 2003, the country was shamed when a 28-year-old Swiss diplomat was forced into her own car by two men in south Delhi's posh Siri Fort area and raped by one of them. The rapist, whom she described as being fluent in English, spoke to her about Switzerland and is believed to have even lectured her on Indian culture.

In 2004 in Manipur, 32-year-old Manorama was taken away from home by the soldiers of Assam Rifles who accused her of helping insurgents. A few hours later, her mutilated body was found by the roadside, her pelvis riddled with dozens of bullets.

Last year, 14-year-old Sonam was raped and killed inside a police station in Uttar Pradesh.

During the 2002 riots in Gujarat, a number of Muslim women were gang-raped, and campaign groups routinely accuse the security forces in Indian-administered Kashmir and the troubled north-east of using rape as a weapon to punish the entire community.

In May 2009, Indian-administered Kashmir witnessed 47 days of violent protests and strikes after two young women were raped and murdered, allegedly by police, in Shopian town.

And in Chhattisgarh, Soni Sori has been in police custody since October 2011 when she was arrested on charges of being a courier for the Maoists. She has alleged in the Supreme Court that while in custody, she has been raped and stones have been shoved inside her vagina.

Most of these victims are still waiting for justice, sometimes years after the crimes have been committed.

The rapists sometimes escape with a light sentence because a judge accepts their argument that they committed the crime because they were drunk, or that they were living away from their family, or they had a family to look after, or that the accused was a high-caste man who could not rape a Dalit - low caste - woman.




</p>
<hr>
<p class="container">
      <a href="#" class="image left"><img src="d6.png" alt="sorry" /></a>AHMEDABAD: A 37-year-old woman from the Memnagar area of the city on Monday filed a case of domestic violence against her husband and in-laws, who were allegedly harassing her for the shape of her nose and pressuring her to undergo cosmetic surgery.
In her FIR, the woman, who has two children, alleged that her in-laws and husband held her to be a ‘bad omen’ for them and blamed her for the death of her first child, a girl, who drowned in a pond near her husband’s house in Patan.
In her FIR with Ghatlodia police, the woman stated that she married a Patan-based man in 2006 according to the wishes of her family.
“They used to taunt me, telling me how bad I looked. My husband told me to undergo cosmetic surgery, saying that my nose is flat and I do not look good. Whenever I countered him, he would hit me,” she said in the FIR.
She further states that her husband would compare her looks with other female members of the family and kept harassing her.
In 2008, she left her husband’s house and filed a case of domestic violence in Patan, but was forced to strike a compromise due to the intervention of her family members.
She later reconciled with her husband and delivered their first child in 2009. She died in four months after she slipped into a pond near the house in Patan. Her in-laws and husband blamed her for the accident, saying she was a ‘bad omen’ for the family, states the FIR.
The complainant later had two sons, and tried to live with her husband and his family peacefully. On April 10 this year, her husband forced her out of the house, after she asked him to move the family to a better, safer house.

</p>

</body>
</html>
