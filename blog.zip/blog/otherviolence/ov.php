<html>
<head>
<meta charset="UTF-8">
<style>

ul {
  list-style-type: none;
  margin: 0;
  padding: 0;
  overflow: hidden;
  background-color: grey;
}

li {
  float: left;
}

li a {
  display: block;
  color: black;
  text-align: center;
  padding: 14px 16px;
}

li a:hover {
  background-color: white;
}

#header {
  background-color: white;
  padding: 30px 10px;
  color: black;
  text-align: center;
  font-size: 70px;
  font-weight: bold;
  position: fixed;
  top: 0;
  width: 100%;
  transition: 0.2s;
}

body {
  background-color: black;
}

body {font-family: Arial, Helvetica, sans-serif;}

.image-container {
  background-image: url("TT.JPG");
  background-size: cover;
  position: relative;
  height: 700px;
}

.text {
  background-color: white;
  color: black;
  font-size: 9vw;
  font-weight: bold;
  margin: 0 auto;
  padding: 10px;
  width: 50%;
  text-align: center;
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  mix-blend-mode: screen;
}

body {
  color: white;
}

h1 {
  color: grey;
  font-size: 450%;
  text-align: center;

}



pre.b {
  font-family: "Times New Roman";
  font-size: `100%;
  padding-left: 15px;
  padding-top: 0px;
  padding-bottom: 50px;
}


pre.c {
  font-family: "Times New Roman";
  font-size: large;
  padding-left: 15px;
  padding-top: 350px;
  padding-bottom: 50px;
}
div.gallery {
  margin: 5px;
  border: 1px solid #ccc;
  float: left;
  width: 400px;
}

div.gallery:hover {
  border: 1px solid #777;
}

div.gallery img {
  width: 100%;
  height: auto;
}

div.desc {
  padding: 15px;
  text-align: center;
}
</style>
</head>


<body>


<div id="header">Other Violence</div>
<div style="margin-top:200px;padding:15px 15px 2500px;font-size:30px">


<!--  <ul>
    <li><a href="index2.php">Home</a></li>
    <li><a class="active" href="welcome.php">Our Blog</a></li>
    <li><a href="inspiration.php">Inspiration</a></li>
    <li><a href="contact.html">Contact</a></li>
  </ul>
-->

<div class="image-container">
  <div class="text">ENOUGH!</div>

</div>

<h2> HUMAN TRAFFICKING</h2>
    <pre class="b">

        	Forms of violence:

        	Rape
        	Marital rape
        	Domestic violence
        	Reproductive coercion
        	Mob violence
        	Dating abuse
        	Sexual violence on college campuses
        	Restrictions on freedom of movement
        	Denial of medical care
        	Stalking
        	Sexual harassment
        	Human trafficking and forced prostitution
        	Mistreatment of widows
        	Accusations of witchcraft
        	State violence
        	Female genital mutilation
        	Breast ironing
        	Obstetric violence
        	Violence against indigenous women
        	Violence against immigrant and refugee women
        	Violence against trans women
        	Sport-related
        	Cyberbullying
    </pre>


<div class="gallery">
  <a target="_blank" href="q1.JPG">
    <img src="q1.JPG" alt="Domestic Violence" width="600" height="400">
  </a>
</div>

<div class="gallery">
  <a target="_blank" href="q2.JPG">
    <img src="q2.JPG" alt="Domestic Violence" width="600" height="400">
  </a>
</div>

<div class="gallery">
  <a target="_blank" href="A1.JPG">
    <img src="A1.JPG" alt="Domestic Violence" width="600" height="400">
  </a>
</div>

<div class="gallery">
  <a target="_blank" href="A2.JPG">
    <img src="A2.JPG" alt="Northern Lights" width="600" height="400">
  </a>
</div>


<div class="gallery">
  <a target="_blank" href="a4.JPG">
    <img src="A4.JPG" alt="Domestic Violence" width="600" height="400">
  </a>
</div>

<div class="gallery">
  <a target="_blank" href="NO1.JPG">
    <img src="NO1.JPG" alt="Domestic Violence" width="600" height="400">
  </a>
</div>

<div class="gallery">
  <a target="_blank" href="T1.JPG">
    <img src="T1.JPG" alt="Domestic Violence" width="600" height="400">
  </a>
</div>

<div class="gallery">
  <a target="_blank" href="RE1.JPG">
    <img src="a.JPG" alt="Domestic Violence" width="600" height="400">
  </a>
</div>

<div class="gallery">
  <a target="_blank" href="T2.JPG">
    <img src="b.jpeg" alt="Domestic Violence" width="600" height="400">
  </a>
</div>

<div class="gallery">
  <a target="_blank" href="q3.JPG">
    <img src="q3.JPG" alt="Domestic Violence" width="600" height="400">
  </a>
</div>



<div class="gallery">
  <a target="_blank" href="A3.JPG">
    <img src="A3.JPG" alt="Domestic Violence" width="600" height="400">
  </a>
</div>

<div class="gallery">
  <a target="_blank" href="T3.JPG">
    <img src="T3.JPG" alt="Domestic Violence" width="600" height="400">
  </a>
</div>


<script>
window.onscroll = function() {scrollFunction()};

function scrollFunction() {
  if (document.body.scrollTop > 50 || document.documentElement.scrollTop > 50) {
    document.getElementById("header").style.fontSize = "30px";
  } else {
    document.getElementById("header").style.fontSize = "90px";
  }
}
</script>


</body>
</html>
