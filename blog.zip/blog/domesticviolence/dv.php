<html>
<head>
<meta charset ="UTF-8">
<style>

ul {
  list-style-type: none;
  margin: 0;
  padding: 0;
  overflow: hidden;
  background-color: grey;
}

li {
  float: left;
}

li a {
  display: block;
  color: black;
  text-align: center;
  padding: 14px 16px;
}

li a:hover {
  background-color: white;
}

#header {
  background-color: white;
  padding: 30px 10px;
  color: black;
  text-align: center;
  font-size: 70px;
  font-weight: bold;
  position: fixed;
  top: 0;
  width: 100%;
  transition: 0.2s;
}

body {
  background-color: black;
}

body {font-family: Arial, Helvetica, sans-serif;}

.image-container {
  background-image: url("NO.jpeg");
  background-size: cover;
  position: relative;
  height: 700px;
}

.text {
  background-color: white;
  color: black;
  font-size: 9vw;
  font-weight: bold;
  margin: 0 auto;
  padding: 10px;
  width: 50%;
  text-align: center;
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  mix-blend-mode: screen;
}

body {
  color: white;
}

h1 {
  color: grey;
  font-size: 400%;
  text-align: center;

}

.center {
  text-align: center;
  text-size-adjust: 80%;
}

pre.b {
  font-family: "Times New Roman";
  font-size: 65%;
  padding-left: 15px;
  padding-top: 350px;
  padding-bottom: 50px;
}

pre.a {
  font-size: 70%;
}

pre.c {
  font-family: "Times New Roman";
  font-size: 65%;
  padding-left: 15px;
  padding-top: 350px;
  padding-bottom: 50px;
}
div.gallery {
  margin: 5px;
  border: 1px solid #ccc;
  float: left;
  width: 400px;
}

div.gallery:hover {
  border: 1px solid #777;
}

div.gallery img {
  width: 100%;
  height: auto;
}

div.desc {
  padding: 15px;
  text-align: center;
}
</style>
</head>


<body>


<div id="header">Domestic Violence</div>
<div style="margin-top:200px;padding:15px 15px 2500px;font-size:30px">


<!--  <ul>
    <li><a href="index2.php">Home</a></li>
    <li><a class="active" href="welcome.php">Our Blog</a></li>
    <li><a href="inspiration.php">Inspiration</a></li>
    <li><a href="contact.html">Contact</a></li>
  </ul>
-->

<div class="image-container">
  <div class="text">NO VIOLENCE</div>

</div>
<div class="center">
    <pre class="a">
      Domestic violence is not physical violence alone. Domestic violence is any behavior the purpose of
      which is to gain power and control over a spouse, partner, girl/boyfriend or intimate family member.
      Abuse is a learned behavior; it is not caused by anger, mental problems, drugs or alcohol, or other common
      excuses.
    </pre>
</div>

<div class="gallery">
  <a target="_blank" href="DV5.JPG">
    <img src="DV5.JPG" alt="Domestic Violence" width="600" height="400">
  </a>
</div>

<div class="gallery">
  <a target="_blank" href="DV2.JPG">
    <img src="DV2.JPG" alt="Domestic Violence" width="600" height="400">
  </a>
</div>

<div class="gallery">
  <a target="_blank" href="RE.JPG">
    <img src="RE.JPG" alt="Domestic Violence" width="600" height="400">
  </a>
</div>

<pre class="b">
  Domestic violence, social and legal concept that, in the broadest sense, refers to any abuse including physical, emotional, sexual, or financial—between intimate partners,
  often living in the same household. The term is often used specifically to designate physical assaults upon women by their male partners, but, though rarer, the victim may
  be a male abused by his female partner, and the term may also be used regarding abuse of both women and men by same-sex partners.

  Estimated annual figures for the number of women in the United States who are subjected to abuse by a male partner range from two to four million. Additional statistics indicate
  that domestic violence ranks as the leading cause of injury to women from age 15 to 44 and that one-third of the American women murdered in any given year are killed by current
  or former boyfriends or husbands.

  Males may also be victims of domestic violence, although instances are both less common and less severe. However, such occurrences are also less likely to be reported, because
  of the fear of ridicule and the lack of support services made available to male abuse victims.
  Perpetrators of domestic violence come from all socioeconomic, cultural, and educational backgrounds. The stresses of poverty and the abuse of such substances as alcohol and
  drugs contribute to the problem.

  Frequently there is no workable solution for female victims of domestic violence. For some victims the unrelenting cycle of violence produces diminished self-esteem, helplessness,
  depression, and exaggerated feelings of imprisonment, even the belief that they deserve abuse. More material obstacles stand in the way of most victims. Many are financially
  dependent on their abusers, and,since many abuse victims are mothers, they particularly fear being unable to support their children if they leave a violent partner. Many fear
  reporting the crime because the police can offer no reliable protection against retaliation. One of the worst problems is that typical abusers often become most violent and
  vengeful precisely when women try to leave; numbers of women have been murdered by male partners when they tried to press charges or win orders of protection.

</pre>
<div class="gallery">
  <a target="_blank" href="DV8.jpeg">
    <img src="DV8.jpeg" alt="Domestic Violence" width="600" height="400">
  </a>
</div>

<div class="gallery">
  <a target="_blank" href="DV9.jpeg">
    <img src="DV9.jpeg" alt="Northern Lights" width="600" height="400">
  </a>
</div>

<div class="gallery">
  <a target="_blank" href="DV10.jpeg">
    <img src="DV10.jpeg" alt="Domestic Violence" width="600" height="400">
  </a>
</div>

<pre class="c">
  Create a safety plan

  Leaving an abuser can be dangerous. Consider taking these precautions:
  Call a women's shelter or domestic violence hotline for advice. Make the call at a safe time — when the abuser isn't around — or from a friend's house or other safe location.
  Pack an emergency bag that includes items you'll need when you leave, such as extra clothes and keys. Leave the bag in a safe place. Keep important personal papers, money and
  prescription medications handy so that you can take them with you on short notice.
  Know exactly where you'll go and how you'll get there.
  Protect your communication and location

  An abuser can use technology to monitor your telephone and online communication and to track your location. If you're concerned for your safety, seek help. To maintain your privacy:
  Use phones cautiously. Your abuser might intercept calls and listen to your conversations. He or she might use caller ID, check your cellphone or search your phone billing records
  to see your call and texting history.
  Use your home computer cautiously. Your abuser might use spyware to monitor your emails and the websites you visit. Consider using a computer at work, the library or at a friend's
   house to seek help.
  Remove GPS devices from your vehicle. Your abuser might use a GPS device to pinpoint your location.
  Frequently change your email password. Choose passwords that would be impossible for your abuser to guess.
  Clear your viewing history. Follow your browser's instructions to clear any record of websites or graphics you've viewed.

</pre>


<div class="gallery">
  <a target="_blank" href="DV1.JPG">
    <img src="DV1.JPG" alt="Domestic Violence" width="600" height="400">
  </a>
</div>

<div class="gallery">
  <a target="_blank" href="RE2.JPG">
    <img src="RE2.JPG" alt="Domestic Violence" width="600" height="400">
  </a>
</div>

<div class="gallery">
  <a target="_blank" href="RE3.JPG">
    <img src="RE3.JPG" alt="Domestic Violence" width="600" height="400">
  </a>
</div>

<div class="gallery">
  <a target="_blank" href="a1.JPG">
    <img src="a1.JPG" alt="Domestic Violence" width="600" height="400">
  </a>
</div>

<div class="gallery">
  <a target="_blank" href="a2.JPG">
    <img src="a2.JPG" alt="Domestic Violence" width="600" height="400">
  </a>
</div>

<div class="gallery">
  <a target="_blank" href="RE1.JPG">
    <img src="DV6.JPG" alt="Domestic Violence" width="600" height="400">
  </a>
</div>



<script>
window.onscroll = function() {scrollFunction()};

function scrollFunction() {
  if (document.body.scrollTop > 50 || document.documentElement.scrollTop > 50) {
    document.getElementById("header").style.fontSize = "30px";
  } else {
    document.getElementById("header").style.fontSize = "90px";
  }
}
</script>


</body>
</html>
