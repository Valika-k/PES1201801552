<html>
<head>
<meta charset="UTF-8">
<style>

ul {
  list-style-type: none;
  margin: 0;
  padding: 0;
  overflow: hidden;
  background-color: grey;
}

li {
  float: left;
}

li a {
  display: block;
  color: black;
  text-align: center;
  padding: 14px 16px;
}

li a:hover {
  background-color: white;
}

#header {
  background-color: white;
  padding: 30px 10px;
  color: black;
  text-align: center;
  font-size: 70px;
  font-weight: bold;
  position: fixed;
  top: 0;
  width: 100%;
  transition: 0.2s;
}

body {
  background-color: black;
}

body {font-family: Arial, Helvetica, sans-serif;}

.image-container {
  background-image: url("NO2.JPG");
  background-size: cover;
  position: relative;
  height: 700px;
}

.text {
  background-color: white;
  color: black;
  font-size: 9vw;
  font-weight: bold;
  margin: 0 auto;
  padding: 10px;
  width: 50%;
  text-align: center;
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  mix-blend-mode: screen;
}

body {
  color: white;
}

h1 {
  color: grey;
  font-size: 450%;
  text-align: center;

}

.center {
  text-align: center;
  text-size-adjust: 80%;
}

pre.b {
  font-family: "Times New Roman", Times, serif;
  font-size: 65%;
  padding-left: 15px;
  padding-top: 350px;
  padding-bottom: 50px;
}

pre.a {
  font-size: 70%;
}

pre.c {
  font-family: "Times New Roman", Times, serif;
  font-size: 65%;
  padding-left: 15px;
  padding-top: 350px;
  padding-bottom: 50px;
}
div.gallery {
  margin: 5px;
  border: 1px solid #ccc;
  float: left;
  width: 400px;
}

div.gallery:hover {
  border: 1px solid #777;
}

div.gallery img {
  width: 100%;
  height: auto;
}

div.desc {
  padding: 15px;
  text-align: center;
}
</style>
</head>


<body>


<div id="header">Women Trafficking</div>
<div style="margin-top:200px;padding:15px 15px 2500px;font-size:30px">


<!--  <ul>
    <li><a href="index2.php">Home</a></li>
    <li><a class="active" href="welcome.php">Our Blog</a></li>
    <li><a href="inspiration.php">Inspiration</a></li>
    <li><a href="contact.html">Contact</a></li>
  </ul>

-->
<div class="image-container">
  <div class="text">SPEAK UP</div>

</div>

<div class="center">
    <pre class="a">



  Human trafficking involves recruitment, harbouring or transporting people into a situation of
  exploitation through the use of violence, deception or coercion and forced to work against their will.
  In other words, trafficking is a process of enslaving people, coercing them into a situation with no
  way out, and exploiting them.
  People can be trafficked for many different forms of exploitation such as forced prostitution, forced
  labour, forced begging, forced criminality, domestic servitude, forced marriage, and forced organ removal.



    </pre>
</div>

<div class="gallery">
  <a target="_blank" href="q1.JPG">
    <img src="q1.JPG" alt="Domestic Violence" width="600" height="400">
  </a>
</div>

<div class="gallery">
  <a target="_blank" href="q2.JPG">
    <img src="q2.JPG" alt="Domestic Violence" width="600" height="400">
  </a>
</div>

<div class="gallery">
  <a target="_blank" href="q3.JPG">
    <img src="q3.JPG" alt="Domestic Violence" width="600" height="400">
  </a>
</div>

<pre class="b">


Contrary to a common misconception, people do not necessarily have to be transported across borders for trafficking to take place. In fact, transporting or moving the
victim doesn’t necessarily define trafficking.
When children are trafficked, no violence or coercion needs to be involved. Simply bringing them into exploitative conditions constitutes trafficking.

Trafficking for sexual exploitation gets much attention. However, the majority of people are trafficked into labour exploitation.

Many people who fall victim of trafficking want to escape poverty, improve their lives, and support their families. Often they get an offer of a well-paid job
abroad or in another region. Often they borrow money from their traffickers in advance to pay for arranging the job, travel and accommodation.

When they arrive they find that the work they applied for does not exist, or the conditions are completely different. But it’s too late, their documents are often
taken away and they are forced to work until their debt is paid off.


</pre>
<div class="gallery">
  <a target="_blank" href="A1.JPG">
    <img src="A1.JPG" alt="Domestic Violence" width="600" height="400">
  </a>
</div>

<div class="gallery">
  <a target="_blank" href="A2.JPG">
    <img src="A2.JPG" alt="Northern Lights" width="600" height="400">
  </a>
</div>

<div class="gallery">
  <a target="_blank" href="A3.JPG">
    <img src="A3.JPG" alt="Domestic Violence" width="600" height="400">
  </a>
</div>

<pre class="c">

  <h2>Types of trafficking</h2>
  Sex trafficking

  Warning of Prostitution and Human trafficking in South Korea for G.I. by United States Forces Korea.
  The International Labour Organization claims that sex trafficking affects 4.5 million people worldwide. Most victims find themselves in coercive or abusive situations
  from which escape is both difficult and dangerous.
  Trafficking for sexual exploitation was formerly thought of as the organized movement of people, usually women, between countries and within countries for sex work
  with the use of physical coercion, deception and bondage through forced debt. However, the Trafficking Victims Protection Act of 2000 (US), does not require movement
  for the offence. The issue becomes contentious when the element of coercion is removed from the definition to incorporate facilitation of consensual involvement in
  prostitution. For example, in the United Kingdom, the Sexual Offences Act 2003 incorporated trafficking for sexual exploitation but did not require those committing
  the offence to use coercion, deception or force, so that it also includes any person who enters the UK to carry out sex work with consent as having been "trafficked."
  In addition, any minor involved in a commercial sex act in
  the US while under the age of 18 qualifies as a trafficking victim, even if no force, fraud or coercion is involved, under the definition of "Severe Forms of
  Trafficking in Persons" in the US Trafficking Victims Protection Act of 2000.
  Sexual trafficking includes coercing a migrant into a sexual act as a condition of allowing or arranging the migration. Sexual trafficking uses physical or sexual
  coercion, deception, abuse of power and bondage incurred through forced debt. Trafficked women and children, for instance, are often promised work in the domestic or
  service industry, but instead are sometimes taken to brothels where they are required to undertake sex work, while their passports and other identification papers are
  confiscated. They may be beaten or locked up and promised their freedom only after earning – through prostitution – their purchase price, as well as their travel and visa
  costs.


  Forced marriage


  A forced marriage is a marriage where one or both participants are married without their freely given consent.[98] Servile marriage is defined as a marriage involving a
  person being sold, transferred or inherited into that marriage. According to ECPAT, "Child trafficking for forced marriage is simply another manifestation of trafficking
  and is not restricted to particular nationalities or countries".
  A forced marriage qualifies as a form of human trafficking in certain situations. If a person is sent abroad, forced into the marriage and then repeatedly compelled to
  engage in sexual conduct with their new spouse, then their experience is that of sex trafficking. If the bride or groom is treated as a domestic servant by their new
  spouse and/or their family, then this is a form of labour trafficking.


  Labour trafficking

  Further information: Unfree labour
  Labour trafficking is the movement of persons for the purpose of forced labour and services. It may involve bonded labour, involuntary servitude, domestic servitude, and
  child labour.Labour trafficking happens most often within the domain of domestic work, agriculture, construction, manufacturing and entertainment; and migrant workers and
  indigenous people are especially at risk of becoming victims.People smuggling operations are also known to traffic people for the exploitation of their labour, for
  example, as transporters.


  Trafficking for organ trade

  Trafficking in organs is a form of human trafficking. It can take different forms. In some cases, the victim is compelled into giving up an organ. In other cases, the victim
  agrees to sell an organ in exchange of money/goods, but is not paid (or paid less). Finally, the victim may have the organ removed without the victim's knowledge (usually
  when the victim is treated for another medical problem/illness – real or orchestrated problem/illness). Migrant workers, homeless persons, and illiterate persons are
  particularly vulnerable to this form of exploitation. Trafficking of organs is an organized crime, involving several offenders:
  * the recruiter
  * the transporter
  * the medical staff
  * the middlemen/contractors
  * the buyers
  Trafficking for organ trade often seeks kidneys. Trafficking in organs is a lucrative trade because in many countries the waiting lists for patients who need transplants are
  very long.

</pre>




<div class="gallery">
  <a target="_blank" href="a4.JPG">
    <img src="a4.JPG" alt="Domestic Violence" width="600" height="400">
  </a>
</div>

<div class="gallery">
  <a target="_blank" href="NO1.JPG">
    <img src="NO1.JPG" alt="Domestic Violence" width="600" height="400">
  </a>
</div>

<div class="gallery">
  <a target="_blank" href="T3.JPG">
    <img src="T3.JPG" alt="Domestic Violence" width="600" height="400">
  </a>
</div>

<div class="gallery">
  <a target="_blank" href="T1.JPG">
    <img src="T1.JPG" alt="Domestic Violence" width="600" height="400">
  </a>
</div>

<div class="gallery">
  <a target="_blank" href="T2.JPG">
    <img src="b.jpeg" alt="Domestic Violence" width="600" height="400">
  </a>
</div>

<div class="gallery">
  <a target="_blank" href="RE1.JPG">
    <img src="RE1.JPG" alt="Domestic Violence" width="600" height="400">
  </a>
</div>


<script>
window.onscroll = function() {scrollFunction()};

function scrollFunction() {
  if (document.body.scrollTop > 50 || document.documentElement.scrollTop > 50) {
    document.getElementById("header").style.fontSize = "30px";
  } else {
    document.getElementById("header").style.fontSize = "90px";
  }
}
</script>


</body>
</html>
