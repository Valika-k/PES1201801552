<html>
<head>
<meta charset="UTF-8">
<style>

ul {
  list-style-type: none;
  margin: 0;
  padding: 0;
  overflow: hidden;
  background-color: grey;
}

li {
  float: left;
}

li a {
  display: block;
  color: black;
  text-align: center;
  padding: 14px 16px;

}

li a:hover {
  background-color: white;
}

#header {
  background-color: white;
  padding: 30px 10px;
  color: black;
  text-align: center;
  font-size: 70px;
  font-weight: bold;
  position: fixed;
  top: 0;
  width: 100%;
  transition: 0.2s;
}

body {
  background-color: black;
}

body {font-family: Arial, Helvetica, sans-serif;}

.image-container {
  background-image: url("a2A.JPG");
  background-size: cover;
  position: relative;
  height: 700px;
}

.text {
  background-color: white;
  color: black;
  font-size: 9vw;
  font-weight: bold;
  margin: 0 auto;
  padding: 10px;
  width: 50%;
  text-align: center;
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  mix-blend-mode: screen;
}

body {
  color: white;
}

h1 {
  color: grey;
  font-size: 450%;
  text-align: center;

}

.center {
  text-align: center;
  text-size-adjust: 80%;
}

pre.b {
  font-family: "Times New Roman";
  font-size: 65%;
  padding-left: 15px;
  padding-top: 350px;
  padding-bottom: 50px;

}

pre.a {
  font-size: 70%;
}

pre.c {
  font-family: "Times New Roman";
  font-size: 65%;
  padding-left: 15px;
  padding-top: 350px;
  padding-bottom: 50px;

}
div.gallery {
  margin: 5px;
  border: 1px solid #ccc;
  float: left;
  width: 400px;
}

div.gallery:hover {
  border: 1px solid #777;
}

div.gallery img {
  width: 100%;
  height: auto;
}

div.desc {
  padding: 15px;
  text-align: center;
}
</style>
</head>


<body>


<div id="header">Acid attack</div>
<div style="margin-top:200px;padding:15px 15px 2500px;font-size:30px">


<!--  <ul>
    <li><a href="C:\Users\VALIKA K\Desktop\xampp2\htdocs\slidedownmenu\index2.php">Home</a></li>
    <li><a class="active" href="slidedownmenu/welcome.php">Our Blog</a></li>
    <li><a href="slidedownmenu/inspiration.php">Inspiration</a></li>
    <li><a href="slidedownmenu/contact.html">Contact</a></li>
  </ul>-->


<div class="image-container">
  <div class="text">STOP</div>

</div>

<div class="center">
    <pre class="a">


  An acid attack, also called acid throwing, a vitriol attack, or vitriolage, is a form of violent
  assault involving the act of throwing acid or a similarly corrosive substance onto the body of
  another "with the intention to disfigure, maim, torture, or kill".


    </pre>
</div>

<div class="gallery">
  <a target="_blank" href="q1.JPG">
    <img src="q1.JPG" alt="Domestic Violence" width="600" height="400">
  </a>
</div>

<div class="gallery">
  <a target="_blank" href="q2.JPG">
    <img src="q2.JPG" alt="Domestic Violence" width="600" height="400">
  </a>
</div>

<div class="gallery">
  <a target="_blank" href="q3.JPG">
    <img src="q3.JPG" alt="Domestic Violence" width="600" height="400">
  </a>
</div>

<pre class="b">

  The most common types of acid used in these attacks are sulfuric and nitric acid. Hydrochloric acid is sometimes used, but is much less damaging. Aqueous solutions
  of strongly alkaline materials, such as caustic soda (sodium hydroxide), are used as well, particularly in areas where strong acids are controlled substances.

  The long term consequences of these attacks may include blindness, as well as eye burns, with severe permanent scarring of the face and body, along with far-reaching
  social, psychological, and economic difficulties.

  Today, acid attacks are reported in many parts of the world, though more commonly in developing countries. Since the 1990s, Bangladesh has been reporting the highest
  number of attacks and highest incidence rates for women, with 3,512 Bangladeshi people acid attacked between 1999 and 2013, and in Pakistan and India acid attacks are
  at an all-time high and increasing every year. Although acid attacks occur all over the world, this type of violence is most common in South Asia. The UK has one of
  the highest rates of acid attacks per capita in the world, according to Acid Survivors Trust International (ASTI). In 2016 there were over 601 acid attacks in the UK
  based on ASTI figures, and 67% of the victims were male, but statistics from ASTI suggest that 80% of victims worldwide are women. Over 1,200 cases were recorded over
  the past five years. From 2011 to 2016 there were 1,464 crimes involving acid or corrosive substance in London alone.

</pre>
<div class="gallery">
  <a target="_blank" href="w1.JPG">
    <img src="w1.JPG" alt="Domestic Violence" width="600" height="400">
  </a>
</div>

<div class="gallery">
  <a target="_blank" href="w2.JPG">
    <img src="w2.JPG" alt="Northern Lights" width="600" height="400">
  </a>
</div>

<div class="gallery">
  <a target="_blank" href="w3.JPG">
    <img src="w3.JPG" alt="Domestic Violence" width="600" height="400">
  </a>
</div>

<pre class="c">
  Motivation of perpetrators

The intention of the attacker is often to humiliate rather than to kill the victim. In Britain such attacks, particularly those against men, are believed to be underreported, and
as a result many of them do not show up in official statistics. Some of the most common motivations of perpetrators include:
Personal conflict regarding intimate relationships, and sexual rejection.
Racial motivations
Sexual related jealousy and lust
Social, political and religious motivations
Gang violence and rivalry
Attacks against minorities
Conflicts over land ownership, farm animals, housing and property
Revenge for refusal of sexual advances, proposals of marriage and demands for dowry
Acid attacks often occur as revenge against a woman who rejects a proposal of marriage or a sexual advance.Gender inequality and women's position in the society, in relation
to men, plays a significant role in these types of attacks.

Attacks against individuals based on their religious beliefs or social or political activities also occur. These attacks may be targeted against a specific individual, due
to their activities, or may be perpetrated against random persons merely because they are part of a social group or community. In Europe, Konstantina Kouneva, currently a
member of the European Parliament, had acid thrown on her in 2008, in what was described as "the most severe assault on a trade unionist in Greece for 50 years." Female
students have had acid thrown in their faces as a punishment for attending school. Acid attacks due to religious conflicts have been also reported. Both males and females
have been victims of acid attacks for refusing to convert to another religion.

Conflicts regarding property issues, land disputes, and inheritance have also been reported as motivations of acid attacks. Acid attacks related to conflicts between criminal
gangs occur in many places, including the UK, Greece, and Indonesia


</pre>




<div class="gallery">
  <a target="_blank" href="e1.JPG">
    <img src="e1.JPG" alt="Domestic Violence" width="600" height="400">
  </a>
</div>

<div class="gallery">
  <a target="_blank" href="e2.JPG">
    <img src="e2.JPG" alt="Domestic Violence" width="600" height="400">
  </a>
</div>

<div class="gallery">
  <a target="_blank" href="e3.JPG">
    <img src="e3.JPG" alt="Domestic Violence" width="600" height="400">
  </a>
</div>

<pre>








</pre>
<div class="gallery">
  <a target="_blank" href="a1.JPG">
    <img src="a1.JPG" alt="Domestic Violence" width="600" height="400">
  </a>
</div>

<div class="gallery">
  <a target="_blank" href="a2.JPG">
    <img src="a2.JPG" alt="Domestic Violence" width="600" height="400">
  </a>
</div>

<div class="gallery">
  <a target="_blank" href="a3.JPG">
    <img src="a3.JPG" alt="Domestic Violence" width="600" height="400">
  </a>
</div>


<script>
window.onscroll = function() {scrollFunction()};

function scrollFunction() {
  if (document.body.scrollTop > 50 || document.documentElement.scrollTop > 50) {
    document.getElementById("header").style.fontSize = "30px";
  } else {
    document.getElementById("header").style.fontSize = "90px";
  }
}
</script>


</body>
</html>
