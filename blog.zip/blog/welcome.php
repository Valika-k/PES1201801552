<?php
// Initialize the session
session_start();

// Check if the user is logged in, if not then redirect him to login page
if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true){
    header("location: login.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <!--<meta charset="UTF-8">-->
    <title>Welcome</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.css">
    <style type="text/css">
        body{ font: 14px sans-serif; text-align: center; }
    </style>
</head>
<body>
    <div class="page-header">


        <h1 >Hi, <b><?php echo  "<font color='white'>".htmlspecialchars($_SESSION["username"])."</font>";?></b>. Welcome to our site.</h1>
    </div>

</body>
</html>


<!DOCTYPE HTML>

<html>
<head>
		<title>Blog</title>
	<!--	<meta http-equiv="content-type" content="text/html; charset=utf-8" />
		<meta name="description" content="" />
		<meta name="keywords" content="" />-->
		<link href='http://fonts.googleapis.com/css?family=Arimo:400,700' rel='stylesheet' type='text/css'>
		<!--[if lte IE 8]><script src="js/html5shiv.js"></script><![endif]-->
		<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.11.0/jquery.min.js"></script>
		<script src="js/skel.min.js"></script>
		<script src="js/skel-panels.min.js"></script>
		<script src="js/init.js"></script>
		<noscript>
			<link rel="stylesheet" href="css/skel-noscript.css" />
			<link rel="stylesheet" href="css/style.css" />
			<link rel="stylesheet" href="css/style-desktop.css" />
		</noscript>
		<!--[if lte IE 8]><link rel="stylesheet" href="css/ie/v8.css" /><![endif]-->
		<!--[if lte IE 9]><link rel="stylesheet" href="css/ie/v9.css" /><![endif]-->
		<style>

	#header
	{
		position: relative;
		background: #2a2f27 url(img-activities.jpg) no-repeat;
		background-size: cover;
	}
	</style>
	</head>
	<body class="homepage">

		<!-- Header -->
		<div id="header">
			<div class="container">

				<!-- Logo -->
				<div id="logo">
					<h1><a href="#">She Matters!</a></h1>
					<span>Someone has to lead.</span>
				</div>

				<!-- Nav -->
				<nav id="nav">
					<ul>
						<li><a href="index2.php">Home</a></li>
							<li class="active"><a href="#">Our Blog</a></li>
              	<li><a href="inspiration.php">Inspiration</a></li>
						<li><a href="https://www.instagram.com/_she_matters_/?hl=en">Media</a></li>

						<li><a href="black_and_white/contact.html">Contact</a></li>



					</ul>
				</nav>
			</div>
		</div>

		<!-- Main -->
		<div id="main">
			<div class="container">
				<div class="row">

					<!-- Content -->
					<div id="content" class="12u skel-cell-important">
						<section>
							<header>
								<h2>Come join with us</h2>
								<span class="byline">If you get, give. If you learn, teach</span>
							</header>
							<a href="#" class="image full"><img src="images1/d9.png" alt="" /></a>
							<p>She's been through more hell than you will ever know.But thats what gives her beauty an edge.You cant touch a woman wear pain like grandest of diamonds around her neck.
She matters...She defenitely does...
A three year old girl is sexually assaulted for 10 days with the consent of her mom!8 year old girl gang-raped by a class 6 guy!Do you remember when an 8-month-old baby girl was raped in Delhi?
Not just middle and teenagers, none, not even the elderly women are safe in our country!

Why dont anyone raise voice against them?!
Is this confined to just a week of rallys and REST IN PEACE shares?
Cant we just not let anyone lose  hope in life just because some brute misbehaved with her?
Cant we educate our children, our siblings, our dear ones what to do to prevent such things?

Yes,we can prevent such things. But by making our daughers wear full clothes, or by not letting them talk to other guys, or by stopping her go out in late nights?? Does it stop everything?
DEFINITELY NO!The thing is things that should happen will happen even when you dont wish them to happen...
Even if u lock yourself up in the room you cant just avoid some situations...And whats wrong in
facing something GIRLS!?
It shouldnt happen yea...it definitely shouldnt! But if it happens why dont you take a stand against it?
Isnt there anyone who doesnt support u?
WE ARE THERE! REMEMBER WE ARE THERE!
Feel free to share your stories and get advice on futhur what to do...
You can also read about some past cases in which many people came out of the worst acid attacks and now leading a
really happy life? Who hasnt faced it? Didnt i? Didnt your mom? Didnt your Best friend? When you want your life to change...first start the change! Share your story!
 Let others know
how you have come out or what you are facing...Read the articles on our page if you are not aware of the different types of issues girls are facing...<br>

REMEMBER, WE ARE WITH YOU!</p>
							<p>Indian Society has always revered women. In Hinduism, man and woman represent the two halves of the divine body. There is no question of superiority or inferiority between them. Hindu history is witness to the super-women, such as Gargi, Maitreyi and Sulabha, whose faculty of reasoning was far superior to that of ordinary mortals. Many female deities Saraswati, Durga, Laxmi, Kali etc., are worshipped across the country. According to the Mahabharat by cherishing the woman one virtually worships the goddess of prosperity.

On the darker side, the patriarchal system has continued since the time of Rig Veda. Customs and values were made by men to favour men. Women suffer this discrimination in silence.

Historically, the Indian woman has been made to adopt contradictory roles. The strength of a woman is evoked to ensure that women effectively play their traditional roles of nurturance as daughters, mothers, wives, and daughters-in-laws. On the other hand, the stereotype of “a weak and helpless woman” is fostered to ensure complete dependence on the male sex.</p>
							<p>Female Abusers When most people think of abusers, their minds go straight towards the stereotypical picture of a man beating a women but men are not the only partners in a relationship that can be abusive. Women also violent towards their intimate partners, it is not just a male crime. The stereotyping of males being the abusers has partly contributed to the reason why there isn’t a lot of data on female abusers. It wasn’t until recently that psychologist had started do research in this field. Some of the data that has come from this newly emerging field is interesting. A number of surveys and research studies have found competing ideas about women who commit intimate partner violence. Some say that men and women are both commit about equal rates of intimate partner violence and some goes as far as to say that women commit more than men. Women might use more violence according to some of these studies but the motives and result of the violence is different among men and women.</p>
						</section>
					</div>

				</div>
			</div>
		</div>


		<div id="featured">
			<div class="container">
				<div class="row">
					<div class="4u">
						<h2>Acid attacks</h2>
						<a href="#" class="image full"><img src="images/acidattack1.png" alt="" /></a>
						<p>Having your face disfigured and burned in a matter of seconds is not what any woman has in mind as a consequence when they refuse to go on a date with a man. The victims's ages range from under ten to approximately thirty. It is happening to very young girls that are just maturing.</p>
						<p><a href="acidattack/aa.php" class="button">More Details</a></p>
					</div>

					<div class="4u">
						<h2>Domestic Violence</h2>
						<a href="#" class="image full"><img src="images/domesticviolence.png" alt="" /></a>
						<p>Every year 4,000 victims of domestic violence are killed. Domestic violence is a crime that is committed worldwide. This crime is committed every day, every hour, every minute and every second. Anybody can be the victim or the abuser.This types of abuse are dangerous psychologically and physically.</p>
						<p><a href="domesticviolence/dv.php" class="button">More Details</a></p>
					</div>

					<div class="4u">
						<h2>Sexual Assault</h2>
						<a href="#" class="image full"><img src="images/sexualassault.png" alt="" /></a>
						<p>Sexual Assault is a harsh realistic nightmare that poses reoccuring issues in our society. Although sexual assault is a very common occurrence, it is a sensitive topic, which leads to people and victims feeling hesitant to talk about it, causing so many cases to remain untouched and victims silenced. Emotionally, victims are conflicted about whether it is their own fault or if it is the fault of the attacker.In many cases, the victim will blame themselves for what has happened to them.Physically there is a nearly always damage in the affected areas.</p>
						<p><a href="sexualassault/sa.php" class="button">More Details</a></p>
					</div>

						<div class="4u">
						<h2>Women Trafficking</h2>
						<a href="#" class="image full"><img src="images/trafficking.png" alt="" /></a>
						<p>Trafficking in persons is an increasing problem that involves both sexual exploitation and labor exploitation of its victims.It is a complicated phenomenon with many forces that affect women's decisions to work abroad.Perhaps the strongest factor is a desperate economic situation.Women may become victims of trafficking when they seek assistance to obtain employment,work permits.</p>
						<p><a href="womentrafficking/wt.php" class="button">More Details</a></p>
					</div>

					<div class="4u">
					<h2>Other Violence</h2>
					<a href="#" class="image full"><img src="images/otherviolence.png" alt="" /></a>
					<p>Women experience violence in many ways from physical abuse to sexual assault and from financial abuse to sexaul harassment or trafficking. Whatever form it takes, violence against women can have serious long-term physical and emotional effects.Gender inequality and norms on the acceptibility of violence against women are a root cause of violence against women.</p>
					<p><a href="otherviolence/ov.php" class="button">More Details</a></p>
				</div>
				</div>
			</div>
		</div>

		<!-- Footer -->
		<div id="footer">
			<div class="container">
				<div class="row">
					<div class="4u">
						<section>
								<a href="#" class="image full"><img src="images/w6.png" alt="" /></a>

						</section>
					</div>

					<div class="4u">
						<section>
							<a href="#" class="image full"><img src="images/w3.png" alt="" /></a>

						</section>
					</div>
					<div class="4u">
						<section>
							<a href="#" class="image full"><img src="images/w4.png" alt="" /></a>
						</section>
					</div>
				</div>
			</div>
		</div>
    <p>
        <a href="reset-password.php" style="background-color:grey" class="btn btn-warning">Reset Your Password</a>
        <a href="logout.php" class="btn btn-danger">Sign Out of Your Account</a>
    </p>




	</body>
</html>
